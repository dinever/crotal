---
layout: post
title: "Hello World!"
date: 2012-01-1 00:00
slug: hello-world
categories: welcome
tags: Hello, World
description: Welcome to Crotal, This is the first post, modify or remove it, and start your own blog!
---

Welcome to Crotal, This is the first post, modify or remove it, and start your own blog!

Write you post like this:

    ---
    title: "Hello, World"
    date: 2013-04-20 15:10
    categories: crotal
    slug: hello-world
    ---

    Welcome to Crotal, This is your first post, modify or remove it, and start your own blog!

Add a picture like this:

    ![Manhattan](/images/Manhattan.jpg)

![Manhattan](/images/Manhattan.jpg)

Check the <a href="http://crotal.org/docs/" target="_blank">documents</a> for more information.
